#include <stdio.h>

const char *message(void);

int main(void) {
  printf("%s\n", message());
  return 0;
}
