#import <UIKit/UIKit.h>

//! Project version number for iOSFramework.
FOUNDATION_EXPORT double iOSFrameworkVersionNumber;

//! Project version string for iOSFramework.
FOUNDATION_EXPORT const unsigned char iOSFrameworkVersionString[];

#import <iOSFramework/Thing.h>
